package com.example.pedulidigital.model

data class MovieListResponse(
    val results: List<Movie>
)